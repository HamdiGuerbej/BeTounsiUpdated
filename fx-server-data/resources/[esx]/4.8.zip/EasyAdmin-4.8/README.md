# [EasyAdmin](https://forum.fivem.net/t/release-easyadmin-its-as-easy-as-it-gets/42245)

## NOTE: BEFORE INSTALLING THIS ON YOUR SERVER, PLEASE READ THE [WIKI](https://github.com/Bluethefurry/EasyAdmin/wiki)

### If you get any errors or issues, please create an [Issue](https://github.com/Bluethefurry/EasyAdmin/issues/new)

**Note: this script is licensed under "[AGPL 3.0](https://tldrlegal.com/license/gnu-affero-general-public-license-v3-(agpl-3.0))"**
